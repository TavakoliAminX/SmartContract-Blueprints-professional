const hre = require("hardhat");

/*
 * Simple Hardhat deployment script
 */
async function main() {
  const Auction = await hre.ethers.getContractFactory("NFTSimpleAuctionContract");

  const auction = await Auction.deploy(
    hre.ethers.constants.AddressZero,
    3600,
    1
  );

  await auction.deployed();
  console.log("Auction deployed at:", auction.address);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
